package boot.entity;

import java.time.LocalDateTime;

import org.hibernate.annotations.DynamicUpdate;

import javax.persistence.*;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Entity
@DynamicUpdate
@AllArgsConstructor
@NoArgsConstructor
public class Bill {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;
	
public Bill() {
    	
    }

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "patient_id")
	private Patient patient;

	@Column(name = "Date")
	private LocalDateTime billDate;

	@Column(name = "Amount")
	private double totalAmount;

	@Column(name = "Status")
	private String paymentStatus;
	
	

	public void setBillDate(LocalDateTime now) {
		this.billDate = now;
	}

}
