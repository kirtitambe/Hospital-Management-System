package boot.entity;

import java.util.List;

import org.hibernate.annotations.DynamicUpdate;

import javax.persistence.*;
import lombok.Data;


@Data
@Entity
@Table(name = "doctor")
@DynamicUpdate
public class Doctor {
    
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
   
    public Doctor() {
    	
    }
    
    @Column(name = "name")
    private String name;
    
    @Column(name = "Email")
    private String email;
    
    @Column(name = "age")
    private String age;
    
    @Column(name = "password")
    private String password;
    
    @Column(name = "gender")
    private String gender;
    
    @Column(name = "phone")
    private String phone;
    
    @Column(name = "specialization")
    private String specialization;
    
    @Column(name = "address")
    private String address;
    
    @Column(name = "City")
    private String city;
    
    
    
    @OneToMany(mappedBy = "doctor", cascade = CascadeType.ALL)
    private List<Appointment> appointments;



	public Long getId() {
		return id;
	}



	public void setId(Long id) {
		this.id = id;
	}



	public String getName() {
		return name;
	}



	public void setName(String name) {
		this.name = name;
	}



	public String getEmail() {
		return email;
	}



	public void setEmail(String email) {
		this.email = email;
	}



	public String getAge() {
		return age;
	}



	public void setAge(String age) {
		this.age = age;
	}



	public String getPassword() {
		return password;
	}



	public void setPassword(String password) {
		this.password = password;
	}



	public String getGender() {
		return gender;
	}



	public void setGender(String gender) {
		this.gender = gender;
	}



	public String getPhone() {
		return phone;
	}



	public void setPhone(String phone) {
		this.phone = phone;
	}



	public String getSpecialization() {
		return specialization;
	}



	public void setSpecialization(String specialization) {
		this.specialization = specialization;
	}



	public String getAddress() {
		return address;
	}



	public void setAddress(String address) {
		this.address = address;
	}



	public String getCity() {
		return city;
	}



	public void setCity(String city) {
		this.city = city;
	}



	public List<Appointment> getAppointments() {
		return appointments;
	}



	public void setAppointments(List<Appointment> appointments) {
		this.appointments = appointments;
	}



	@Override
	public String toString() {
		return "Doctor [id=" + id + ", name=" + name + ", email=" + email + ", age=" + age + ", password=" + password
				+ ", gender=" + gender + ", phone=" + phone + ", specialization=" + specialization + ", address="
				+ address + ", city=" + city + ", appointments=" + appointments + "]";
	}



	public Doctor(Long id, String name, String email, String age, String password, String gender, String phone,
			String specialization, String address, String city, List<Appointment> appointments) {
		super();
		this.id = id;
		this.name = name;
		this.email = email;
		this.age = age;
		this.password = password;
		this.gender = gender;
		this.phone = phone;
		this.specialization = specialization;
		this.address = address;
		this.city = city;
		this.appointments = appointments;
	}
    
    // constructors, getters, and setters
}
