package boot.dto;

import java.time.LocalDateTime;

import boot.entity.Appointment;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class AppointmentDTO {
    
    private Long id;
    private PatientDTO patient;
    private DoctorDTO doctor;
    private LocalDateTime appointmentDateTime;
    private String status;
    

    public AppointmentDTO() {
    	
    }
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public PatientDTO getPatient() {
		return patient;
	}
	public void setPatient(PatientDTO patient) {
		this.patient = patient;
	}
	public DoctorDTO getDoctor() {
		return doctor;
	}
	public void setDoctor(DoctorDTO doctor) {
		this.doctor = doctor;
	}
	public LocalDateTime getAppointmentDateTime() {
		return appointmentDateTime;
	}
	public void setAppointmentDateTime(LocalDateTime appointmentDateTime) {
		this.appointmentDateTime = appointmentDateTime;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	@Override
	public String toString() {
		return "AppointmentDTO [id=" + id + ", patient=" + patient + ", doctor=" + doctor + ", appointmentDateTime="
				+ appointmentDateTime + ", status=" + status + "]";
	}
	
	public AppointmentDTO(Long id, PatientDTO patient, DoctorDTO doctor, LocalDateTime appointmentDateTime,
			String status) {
		super();
		this.id = id;
		this.patient = patient;
		this.doctor = doctor;
		this.appointmentDateTime = appointmentDateTime;
		this.status = status;
	}
    
  

	
}
