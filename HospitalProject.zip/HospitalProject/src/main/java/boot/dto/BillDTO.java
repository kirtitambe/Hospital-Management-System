package boot.dto;

import java.time.LocalDateTime;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class BillDTO {

	private Long id;
	private PatientDTO patient;

	private LocalDateTime billDate;
	private double totalAmount;
	private String paymentStatus;
	

    public BillDTO() {
    	
    }
}
